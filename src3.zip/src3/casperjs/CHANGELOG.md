[This file has moved to Github](https://github.com/casperjs/casperjs/releases)
