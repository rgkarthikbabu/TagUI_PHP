document.location.href =
    "https://docs.google.com/presentation?usp=chrome_app&authuser=0";
